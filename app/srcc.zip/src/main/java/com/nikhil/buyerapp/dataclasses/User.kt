package com.nikhil.buyerapp.dataclasses

import java.util.Date


data class User (
    val uid: String,
    val email: String,
    val occupation:String,
    val createdon: Date = Date(),
    val fullName: String?=null,
    val phoneNumber: String?=null,
    val profilePictureUrl: String?=null,
    val state: String? =null,
    val bio: String?=null,
    val language:List<String> = listOf(),
    val userole:UserRole,

)
enum class UserRole{
    CLIENT,
    FREELANCER,
    ADMIN
}