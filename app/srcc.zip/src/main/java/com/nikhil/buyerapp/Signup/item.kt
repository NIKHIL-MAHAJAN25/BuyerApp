package com.nikhil.buyerapp.Signup

class item (
    val drawableResId: Int,
    val title: String,
    val description: String
    )